import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
function Body1(){
    return(
        <div>
        <form>
          <label>
            <br></br>
            Employee Name:
             <input id="name1" type="text" name="Employee Name" />
             <br></br>
             Qualification:
            <input id="name2" type="text" name="Qualification" />
            <br></br>
            Designation:
            <input id="name3" type="text" name="Designation" />
            <br></br>
            Salary:
            <input id="t1" type="text" name="Salary" />
          </label>
        <input type="submit" value="Submit" />
        </form>
        </div>    
    );
}
export default Body1;