import React from 'react';

class R extends React.Component{
    render(){
        return( <h1> hello</h1>/*<div >
            <h1  id="name1" >[A.Nikhil]</h1> 
            <h4 id="name2" >alla.nikhil.500@gmail.com</h4>
            <h4 id="name2" >  [cb.en.u4cse17203@cb.students.amrita.edu]</h4>
            <h2>EDUCATION</h2>
            <hr></hr>
        
            <pre id="name3">
               <b>Amrita Vishwa Vidyapeetham,Coimbatore</b>                                                                                                            <span class="sp">21-6-2019</span>    
                           <pre id='margin'>B-tech in Computer Science<br></br>
            
                          Expected Graduation:<br></br></pre>
            
                <b>university of washington School of Public Health-Seattle,WA</b>                                                                      <span class="sp">20-6-2019</span>                             
                <br></br >
                <pre id='margin'>BTECH</pre>
                <br></br>
                <b>BTECH-COIMBATORE</b>                                                                                                                                                      <span class="sp">22-6-2019</span>      
               <br></br >
            
                         <pre id='margin'>BTECH,CSE-IT <br></br>
            
                          BFA<br></br></pre>
            </pre>
            <h2>HONORS & AWARDS</h2>
            <hr></hr>
            <pre id="name3">
               <b>STUDENT OF THE YEAR</b>                                                                                                                                                 <span class="sp">2017</span>                      
            </pre>
            <h2>RESEARCH EXPERIENCE</h2>
            <hr></hr>
            <pre id="name3">
               <b>TECH.SOL</b>                                                                                                                                                                             <span class="sp">2016</span>                                                                
               <pre id="margin">
                   GO Coding:
                   <br></br>
                    <ul>
                        <li>The project is about current Installing Proccess</li>
                        <li>Team:ME,Sasank,Surya&Jai Krishna</li>
                        </ul> 
               </pre>
            </pre>
            <h2>PRESENTATIONS</h2>
            <hr></hr>
            <pre id="name3">
               <b>ABS-AVINASHI ROAD</b>                                                                                                                                                     <span class="sp">2019</span> 
               <br></br>
               <b>RAJ BHAVAN-TOWN HALL</b>                                                                                                                                           <span class="sp">2018</span>                        
            </pre>
            
            </div>*/


        );
    }
}
export default R;