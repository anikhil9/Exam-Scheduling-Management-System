import React from 'react';
import ReactDOM from 'react-dom';
import Header from './Header';
function S(){
    return(<h1 id="name1" >ADD NEW EMPLOYEE</h1>,
    <Header />
    );
}
export default S;