var http = require('http');

http.createServer(function (req,res){
  res.writeHead(50000,{'content-type':'text/html'});
  res.end('hello world');
}).listen(8080);